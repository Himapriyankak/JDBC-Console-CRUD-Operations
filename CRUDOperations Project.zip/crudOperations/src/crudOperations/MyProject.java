package crudOperations;

import java.util.ArrayList;

public class MyProject {

	public static void main(String[] args) {
		CrudOperations co = new CrudOperations();
		co.createtable();
		co.insert(1,"priyanka",2, 23000);
		co.insert(2, "siri", 1, 20000);
		co.insert(3,"satish", 5, 65000);
		co.insert(4,"sahi",1,20000);
		co.insert(5,"renu",3,43000);
		co.update(3, 50000);
		co.delete(5);
		ArrayList<Employee> a1 = CrudOperations.read();
		for(Employee e :a1) {
			System.out.println(e.getEid()+" "+e.getName()+" "+e.getExp()+" "+e.getSalary());
		}
		

	}

}
