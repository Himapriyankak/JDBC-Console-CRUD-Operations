package crudOperations;

public class Employee {
    int eid;
    String name;
    int exp;
    int salary;
	public Employee(int eid, String name, int exp, int salary) {
		super();
		this.eid = eid;
		this.name = name;
		this.exp = exp;
		this.salary = salary;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getExp() {
		return exp;
	}
	public void setExp(int exp) {
		this.exp = exp;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
    
}
