package crudOperations;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class CrudOperations {
	static String url = "jdbc:mysql://localhost:3306/Data";
	static String username = "root";
	static  String password ="admin";
	static Connection c = null;
	static Statement s = null;
	static PreparedStatement ps = null;
    static String createTable = "create table Employee(eid int, name varchar(40),exp int,salary int)";
    static String insert = "insert into Employee (eid,name,exp,salary)values(?,?,?,?)";
	static String update ="update Employee set salary = ? where eid = ?";
	static String delete = "delete from Employee where eid = ?";

	public static void createtable()
	{
    try 
    {
     Class.forName("com.mysql.cj.jdbc.Driver");
     c = DriverManager.getConnection(url,username,password);
     s = c.createStatement();
     s.executeUpdate(createTable);     
   }
	catch(ClassNotFoundException|SQLException e)
    {
		e.printStackTrace();
	}
	finally {
		try {
			s.close();
			c.close();	
		    }
		catch(SQLException e)
		{
			e.printStackTrace();
			
		}
		}
	}
    	public  static void insert(int eid ,String name,int exp,int salary)
    	{
        try 
        {
         Class.forName("com.mysql.cj.jdbc.Driver");
         c = DriverManager.getConnection(url,username,password);
         ps = c.prepareStatement(insert);
         ps.setInt(1, eid);
         ps.setString(2, name);
         ps.setInt(3, exp);
         ps.setInt(4, salary);
         ps.executeUpdate();
  
        }
    	catch(ClassNotFoundException|SQLException e)
        {
    		e.printStackTrace();
    	}
    	finally {
    		try {
    			ps.close();
    			c.close();
    			
    		    }
    		catch(SQLException e)
    		{
    			e.printStackTrace();
    			
    		}
    	}
        }
    	public  static void update(int salary,int eid)
    	{
        	try 
        	{
         Class.forName("com.mysql.cj.jdbc.Driver");
         c = DriverManager.getConnection(url,username,password);
         ps = c.prepareStatement(update);
         ps.setInt(1, eid);
         ps.setInt(2, salary);
         ps.executeUpdate();
  
    }
    	catch(ClassNotFoundException|SQLException e)
        	{
    		e.printStackTrace();
    	}
    	finally {
    		try {
    			ps.close();
    			c.close();	
    		}
    		catch(SQLException e){
    			e.printStackTrace();
    			
    		}
    		}
    	}
        	public  static void delete(int eid)
        	{
            	try 
            	{
             Class.forName("com.mysql.cj.jdbc.Driver");
             c = DriverManager.getConnection(url,username,password);
             ps = c.prepareStatement(delete);
             ps.setInt(1, eid);
             ps.executeUpdate();
      
        }
        	catch(ClassNotFoundException|SQLException e)
            	{
        		e.printStackTrace();
        	}
        	finally {
        		try {
        			ps.close();
        			c.close();
        			
        		}
      catch(SQLException e)
        	{
        			e.printStackTrace();
	
        	}
        	}
            	}
	public static ArrayList<Employee>read() {
		ArrayList<Employee> a1 = new ArrayList<Employee> ();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection(url,username,password);
            s = c.createStatement();
		ResultSet rs = s.executeQuery("select * from employee");
		while(rs.next()) {
		int eid = rs.getInt("eid");
		String name = rs.getString("name");
		int exp = rs.getInt("exp");
		int salary = rs.getInt("salary");
		Employee e = new Employee(eid, name, exp, salary);
		a1.add(e);	
		}}
		catch(ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				s.close();
				c.close();
				
			}
			catch(SQLException e){
				e.printStackTrace();
				
			}}
		return a1;
		}
		
}

