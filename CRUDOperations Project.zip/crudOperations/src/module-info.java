/**
 * 
 */
/**
 * 
 */
module crudOperations {
	requires java.sql;
}